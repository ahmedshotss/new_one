// products.js
// Single source of truth for the catalog. Swap image paths, prices, and
// copy here — index.html and the product modal render entirely from this.

const PRODUCTS = [
  {
    id: "tidewave-runner",
    name: "Tidewave Runner",
    price: 100,
    image: "assets/products/shoe-01-tidewave-runner.webp",
    alt: "Navy knit sneaker with a textured mesh upper and a chevron-tread outsole",
    tagline: "Everyday knit, built for miles.",
    description:
      "A stretch-knit upper that moves with your foot, a low-profile sole for all-day wear, and reinforced eyelets that hold laces through repeat wear. Made for warm mornings and long walks on the boardwalk.",
    details: ["Breathable knit mesh upper", "Chevron-tread rubber outsole", "Reinforced lace eyelets", "Sizes 7–12"]
  },
  {
    id: "lagoon-trainer",
    name: "Lagoon Trainer",
    price: 300,
    image: "assets/products/shoe-02-lagoon-trainer.webp",
    alt: "Black running shoe with teal side stripes and a cushioned midsole",
    tagline: "Trains hard, wears easy.",
    description:
      "A performance trainer with a cushioned midsole and a supportive knit collar. Teal accent stripes cut through the black upper for a shoe that goes from the track to the street without changing pace.",
    details: ["Cushioned foam midsole", "Supportive knit collar", "Durable rubber outsole", "Sizes 6–13"]
  },
  {
    id: "harbor-slipon",
    name: "Harbor Slip-On",
    price: 150,
    image: "assets/products/shoe-03-harbor-slipon.webp",
    alt: "Black mesh slip-on sneaker with an elastic side gore and a thick sole",
    tagline: "No laces. No fuss.",
    description:
      "An elastic-gore slip-on in breathable black mesh, built for the days you don't want to bend down and tie a thing. The thick sole keeps it grounded; the mesh keeps it cool.",
    details: ["Elastic side-gore entry", "Breathable mesh upper", "Thick cushioned sole", "Sizes 6–12"]
  },
  {
    id: "cognac-deck-slipon",
    name: "Cognac Deck Slip-On",
    price: 400,
    image: "assets/products/shoe-04-cognac-deck-slipon.webp",
    alt: "Cognac brown leather slip-on sneaker with elastic gussets and a white sole",
    tagline: "Leather, without the laces.",
    description:
      "Full-grain leather in a warm cognac tone, with twin elastic gussets for a clean slip-on fit and a white platform sole underneath. Dressy enough for dinner, easy enough for the marina.",
    details: ["Full-grain leather upper", "Dual elastic gussets", "White platform sole", "Sizes 7–12"]
  },
  {
    id: "midnight-oxford",
    name: "Midnight Patent Oxford",
    price: 250,
    image: "assets/products/shoe-05-midnight-oxford.webp",
    alt: "Black patent leather lace-up oxford shoe with a textured toe panel",
    tagline: "Shine that means business.",
    description:
      "A high-shine patent oxford with a textured perforated toe panel and a low block heel. Built for the evenings the rest of the collection is earning its keep for.",
    details: ["Patent leather upper", "Perforated toe detailing", "Low block heel", "Sizes 7–12"]
  },
  {
    id: "breakwater-runner",
    name: "Breakwater Runner",
    price: 500,
    image: "assets/products/shoe-06-breakwater-runner.webp",
    alt: "White running shoe with light blue panels and orange accent details",
    tagline: "Light on the foot, loud in the light.",
    description:
      "A white-and-sky-blue runner with a soft high-rebound midsole and orange accents that catch the eye at pace. Our lightest build this season — made for the long run.",
    details: ["High-rebound cushioned midsole", "Breathable engineered mesh", "Reflective accent trim", "Sizes 6–13"]
  },
  {
    id: "regatta-court",
    name: "Regatta Court Sneaker",
    price: 300,
    image: "assets/products/shoe-07-regatta-court.webp",
    alt: "White court sneaker with green racing stripes and a suede toe cap",
    tagline: "Court classic, summer palette.",
    description:
      "A retro court sneaker with a suede toe cap, twin racing stripes, and a low white sole. Clean enough for the office, casual enough for everything after it.",
    details: ["Suede toe cap", "Canvas and synthetic upper", "Low-profile rubber sole", "Sizes 7–12"]
  }
];
