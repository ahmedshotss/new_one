// main.js
// Renders the product grid and modal from PRODUCTS (js/products.js),
// runs the "buy 2 get 3rd free" calculator, and handles the mobile nav.

(function () {
  "use strict";

  const money = (n) => `$${n.toFixed(0)}`;

  /* ---------------------------------------------------------
     Mobile nav
     --------------------------------------------------------- */
  const navToggle = document.getElementById("navToggle");
  const mainNav = document.getElementById("mainNav");
  navToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(open));
  });

  /* ---------------------------------------------------------
     Product grid
     --------------------------------------------------------- */
  const grid = document.getElementById("productGrid");

  function renderGrid() {
    grid.innerHTML = PRODUCTS.map(
      (p) => `
      <button class="product-card" role="listitem" data-id="${p.id}" aria-haspopup="dialog">
        <span class="product-media">
          <img src="${p.image}" alt="${p.alt}" loading="lazy" />
        </span>
        <span class="product-body">
          <span class="product-name">${p.name}</span>
          <span class="product-tagline">${p.tagline}</span>
          <span class="price-tag">
            <span class="stub">Price</span>
            <span class="amount">${money(p.price)}</span>
          </span>
        </span>
      </button>`
    ).join("");

    grid.querySelectorAll(".product-card").forEach((card) => {
      card.addEventListener("click", () => openModal(card.dataset.id));
    });
  }

  /* ---------------------------------------------------------
     Product detail modal
     --------------------------------------------------------- */
  const backdrop = document.getElementById("modalBackdrop");
  const modalClose = document.getElementById("modalClose");
  const modalImage = document.getElementById("modalImage");
  const modalTitle = document.getElementById("modalTitle");
  const modalTagline = document.getElementById("modalTagline");
  const modalPrice = document.getElementById("modalPrice");
  const modalDescription = document.getElementById("modalDescription");
  const modalDetails = document.getElementById("modalDetails");

  let lastFocused = null;

  function openModal(id) {
    const p = PRODUCTS.find((item) => item.id === id);
    if (!p) return;

    modalImage.src = p.image;
    modalImage.alt = p.alt;
    modalTitle.textContent = p.name;
    modalTagline.textContent = p.tagline;
    modalPrice.textContent = money(p.price);
    modalDescription.textContent = p.description;
    modalDetails.innerHTML = p.details.map((d) => `<li>${d}</li>`).join("");

    lastFocused = document.activeElement;
    backdrop.classList.add("open");
    modalClose.focus();
    document.addEventListener("keydown", onModalKeydown);
  }

  function closeModal() {
    backdrop.classList.remove("open");
    document.removeEventListener("keydown", onModalKeydown);
    if (lastFocused) lastFocused.focus();
  }

  function onModalKeydown(e) {
    if (e.key === "Escape") closeModal();
  }

  modalClose.addEventListener("click", closeModal);
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) closeModal();
  });

  /* ---------------------------------------------------------
     Promo calculator — "buy 2, get the 3rd free"
     Simulates the discount rule a real cart would apply:
     the cheapest of any three selected items is free.
     --------------------------------------------------------- */
  const promoPicks = document.getElementById("promoPicks");
  const promoTotal = document.getElementById("promoTotal");

  function renderPromoPicks() {
    const options = PRODUCTS.map(
      (p) => `<option value="${p.id}">${p.name} — ${money(p.price)}</option>`
    ).join("");

    promoPicks.innerHTML = [0, 1, 2]
      .map(
        (i) => `
      <label class="promo-pick-row">
        Pick ${i + 1}
        <select data-slot="${i}">
          ${options}
        </select>
      </label>`
      )
      .join("");

    // Default to three distinct products so the demo is meaningful on load
    promoPicks.querySelectorAll("select").forEach((sel, i) => {
      sel.value = PRODUCTS[i % PRODUCTS.length].id;
      sel.addEventListener("change", updatePromoTotal);
    });

    updatePromoTotal();
  }

  function updatePromoTotal() {
    const selects = Array.from(promoPicks.querySelectorAll("select"));
    const chosen = selects.map((sel) => PRODUCTS.find((p) => p.id === sel.value));
    const prices = chosen.map((p) => p.price).sort((a, b) => a - b);
    const subtotal = prices.reduce((sum, n) => sum + n, 0);
    const freeItem = prices[0] || 0;
    const total = subtotal - freeItem;

    promoTotal.innerHTML = `
      <div class="line"><span>Subtotal (3 items)</span><span>${money(subtotal)}</span></div>
      <div class="line save"><span>3rd-item discount</span><span>&minus;${money(freeItem)}</span></div>
      <div class="line grand"><span>Total</span><span>${money(total)}</span></div>
    `;
  }

  /* ---------------------------------------------------------
     Init
     --------------------------------------------------------- */
  renderGrid();
  renderPromoPicks();
})();
